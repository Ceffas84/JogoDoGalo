﻿namespace JogoDoGaloV1._0
{
    internal class ProtocolSI
    {
    }
}